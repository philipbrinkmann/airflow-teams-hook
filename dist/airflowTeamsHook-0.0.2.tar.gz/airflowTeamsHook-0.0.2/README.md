# Airflow Teams Hook

This is a simple package to allow custom webhooks into MS Teams to be installed into an Apache Airflow
installation. The code for the hook and operator were taken from [mendhak](https://github.com/mendhak/Airflow-MS-Teams-Operator)
on GitHub.
